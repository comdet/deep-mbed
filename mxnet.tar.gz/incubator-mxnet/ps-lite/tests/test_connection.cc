#include "ps/ps.h"

int main(int argc, char *argv[]) {
  ps::Start();
  // do nothing
  ps::Finalize();
  return 0;
}
