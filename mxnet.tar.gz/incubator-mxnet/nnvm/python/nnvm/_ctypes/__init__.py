""""ctypes implementation of the Symbol"""
