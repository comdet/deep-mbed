# MxNet C++ Package

[![Build Status](https://travis-ci.org/dmlc/MXNet.cpp.svg?branch=master)](https://travis-ci.org/dmlc/MXNet.cpp)
[![Build status](https://ci.appveyor.com/api/projects/status/ckfq6j53sg5ll01d/branch/master?svg=true)](https://ci.appveyor.com/project/lx75249/mxnet-cpp/branch/master)

The examples dir containers examples for you to get started.
The lib dir should contain the compiled mxnet library.
Windows dir contains Visual C++ solution files and project files.
