Change Log
=====

mshadow-1.0
=====
* Initial release

mshadow-2.0: in progress
=====
* Support multiple data type
* Great refactoring of code
* Parameter server interface for MultiGPU and distributed learning
