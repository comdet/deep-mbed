**Distributed Deep Learning Made Easy has found more love and new home, please visit  
[awslabs/deeplearning-cfn](https://github.com/awslabs/deeplearning-cfn)**